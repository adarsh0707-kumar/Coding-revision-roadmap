/*
30. Pointer Safety

Demonstrate null pointers, pointer validation, dynamic memory, deallocation, and dangling pointers, safely.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 30.cpp -o program
*/

#include <iostream>
using namespace std;

// Prints *ptr only when it is safe to do so.
void safePrint(const char *label, const int *ptr) {
    if (ptr != nullptr)
        cout << label << ": value = " << *ptr << '\n';
    else
        cout << label << ": pointer is null, NOT dereferencing\n";
}

int main() {
    // 1. Null pointer: initialised to "points nowhere", checked before use.
    int *nullPtr = nullptr;
    safePrint("1. null pointer", nullPtr);

    // 2. Valid pointer to an ordinary (stack) variable, validated before use.
    int local = 42;
    int *validPtr = &local;
    safePrint("2. pointer to a local variable", validPtr);

    // 3. Dynamic allocation: allocate, assign, print.
    int *heapPtr = new int(100);
    safePrint("3. heap pointer", heapPtr);
    *heapPtr = 200;
    safePrint("3. after assignment", heapPtr);

    // 5. (set-up) A second pointer to the SAME heap block.
    int *alias = heapPtr;

    // 4. Deallocate and reset the pointer we freed through.
    delete heapPtr;
    heapPtr = nullptr;
    safePrint("4. after delete + reset", heapPtr);

    // 5. 'alias' still holds the old address, but that memory has been released.
    //    It is now a DANGLING pointer: dereferencing it is undefined behavior
    //    (the memory may be reused, unmapped, or still hold stale data), so we
    //    do not touch it. The cure is to reset it too.
    cout << "5. 'alias' is now dangling (not dereferenced)\n";
    alias = nullptr;
    safePrint("5. alias after reset", alias);

    return 0;
}
