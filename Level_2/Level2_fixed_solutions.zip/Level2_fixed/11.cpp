/*
11. Reverse a String

Reverse a string without a built-in reverse function.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 11.cpp -o program
*/

#include <iostream>
#include <string>
using namespace std;

void reverseString(string &s) {
    size_t n = s.size();
    for (size_t i = 0; i < n / 2; i++) {       // n == 0 -> loop never runs
        char temp = s[i];
        s[i] = s[n - 1 - i];
        s[n - 1 - i] = temp;
    }
}

int main() {
    string s;
    cout << "Enter a string: ";
    if (!getline(cin, s)) {                    // end of input or read error
        cout << "No input\n";
        return 0;
    }

    reverseString(s);
    cout << "Reversed: " << s << '\n';
    return 0;
}
