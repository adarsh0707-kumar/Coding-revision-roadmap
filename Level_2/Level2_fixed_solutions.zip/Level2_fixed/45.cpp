/*
45. Matrix Addition and Transposition

Add two compatible matrices and compute the transpose of a matrix.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 45.cpp -o program
*/

#include <iostream>
#include <stdexcept>
#include <vector>
using namespace std;

using Matrix = vector<vector<long long>>;           // long long: sums cannot overflow int

bool readMatrix(const char *name, Matrix &m) {
    int rows, cols;
    cout << "Enter the number of rows and columns of " << name << ": ";
    if (!(cin >> rows >> cols) || rows < 1 || cols < 1) return false;
    m.assign(rows, vector<long long>(cols));
    cout << "Enter " << rows << " x " << cols << " values, row by row: ";
    for (auto &row : m)
        for (long long &x : row)
            if (!(cin >> x)) return false;
    return true;
}

void printMatrix(const Matrix &m) {
    for (const auto &row : m) {
        for (size_t j = 0; j < row.size(); j++) {
            if (j > 0) cout << ' ';
            cout << row[j];
        }
        cout << '\n';
    }
}

// Element-wise sum. Throws if the shapes differ.
Matrix addMatrices(const Matrix &a, const Matrix &b) {
    if (a.size() != b.size() || a[0].size() != b[0].size())
        throw invalid_argument("matrices must have the same dimensions");
    Matrix sum(a.size(), vector<long long>(a[0].size()));
    for (size_t i = 0; i < a.size(); i++)
        for (size_t j = 0; j < a[0].size(); j++)
            sum[i][j] = a[i][j] + b[i][j];
    return sum;
}

// An r x c matrix becomes c x r, with transposed[j][i] = m[i][j].
Matrix transpose(const Matrix &m) {
    Matrix t(m[0].size(), vector<long long>(m.size()));
    for (size_t i = 0; i < m.size(); i++)
        for (size_t j = 0; j < m[0].size(); j++)
            t[j][i] = m[i][j];
    return t;
}

int main() {
    Matrix a, b;
    if (!readMatrix("matrix A", a) || !readMatrix("matrix B", b)) {
        cout << "Invalid input\n";
        return 1;
    }

    cout << "\nTranspose of A:\n";
    printMatrix(transpose(a));
    cout << "Transpose of B:\n";
    printMatrix(transpose(b));

    try {
        cout << "\nA + B:\n";
        printMatrix(addMatrices(a, b));
    } catch (const invalid_argument &e) {
        cout << "Cannot add: " << e.what() << '\n';          // handled: no crash
    }
    return 0;
}
