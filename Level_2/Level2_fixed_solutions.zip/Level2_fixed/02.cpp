/*
2. Find the Smallest Element

Find the minimum element of an array.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 02.cpp -o program
*/

#include <iostream>
#include <iterator>
using namespace std;

bool findSmallest(const int arr[], int n, int &result) {
    if (n <= 0) return false;
    int smallest = arr[0];
    for (int i = 1; i < n; i++)
        if (arr[i] < smallest)
            smallest = arr[i];
    result = smallest;
    return true;
}

int main() {
    int a[] = {4, 7, 9, 9, 0, 7, -2, -1, 67, 6};
    int b[] = {5, 5, 5};

    int result;
    if (findSmallest(a, static_cast<int>(size(a)), result)) cout << "Smallest: " << result << '\n';
    if (findSmallest(b, static_cast<int>(size(b)), result)) cout << "Smallest: " << result << '\n';
    if (!findSmallest(a, 0, result)) cout << "Empty array: no smallest element\n";
    return 0;
}
