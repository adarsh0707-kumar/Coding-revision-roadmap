/*
36. Binary Search Recursively

Implement binary search recursively on a sorted array.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 36.cpp -o program
*/

#include <cstddef>
#include <iostream>
#include <vector>
using namespace std;

// Searches arr[low, high). Returns the index of a match, or -1.
ptrdiff_t binarySearch(const vector<int> &arr, int target, size_t low, size_t high) {
    if (low >= high) return -1;                          // empty range: not found

    size_t mid = low + (high - low) / 2;                 // no overflow, no underflow

    if (arr[mid] == target) return static_cast<ptrdiff_t>(mid);
    if (arr[mid] > target)  return binarySearch(arr, target, low, mid);       // left half
    return binarySearch(arr, target, mid + 1, high);                          // right half
}

int main() {
    int n;
    cout << "Enter the number of elements: ";
    if (!(cin >> n) || n < 0) {
        cout << "Invalid size\n";
        return 1;
    }

    vector<int> arr(n);
    cout << "Enter " << n << " integers in ascending order: ";
    for (int &x : arr) {
        if (!(cin >> x)) {
            cout << "Invalid input\n";
            return 1;
        }
    }
    for (int i = 1; i < n; i++) {
        if (arr[i - 1] > arr[i]) {
            cout << "The array must be sorted in ascending order\n";
            return 1;
        }
    }

    int target;
    cout << "Enter the target: ";
    if (!(cin >> target)) {
        cout << "Invalid input\n";
        return 1;
    }

    ptrdiff_t index = binarySearch(arr, target, 0, arr.size());
    if (index != -1) cout << "Found at index " << index << '\n';
    else             cout << "Not found\n";
    return 0;
}
