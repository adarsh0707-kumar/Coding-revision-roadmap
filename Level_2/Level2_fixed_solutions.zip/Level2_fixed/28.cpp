/*
28. Find the Largest Element Using Pointers

Find the maximum array element using pointers.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 28.cpp -o program
*/

#include <iostream>
#include <iterator>
using namespace std;

// Pointer to the largest element in [first, last), or nullptr if the range is empty.
const int *maxElement(const int *first, const int *last) {
    if (first == last) return nullptr;
    const int *best = first;
    for (const int *p = first + 1; p != last; ++p)
        if (*p > *best)
            best = p;
    return best;
}

int main() {
    int arr[] = {10, 30, 20, 43, 34, 32, 3, 42, 0, 44, 1};
    int n = static_cast<int>(size(arr));

    const int *best = maxElement(arr, arr + n);
    if (best)
        cout << "Largest: " << *best << " at index " << (best - arr) << '\n';

    int negatives[] = {-8, -3, -20};
    best = maxElement(negatives, negatives + 3);
    cout << "Largest of negatives: " << *best << '\n';

    if (maxElement(arr, arr) == nullptr)
        cout << "Empty range: no maximum\n";
    return 0;
}
