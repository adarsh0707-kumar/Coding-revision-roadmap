/*
41. Insertion Sort

Implement insertion sort and test it on sorted, reversed and random input.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 41.cpp -o program
*/

#include <algorithm>
#include <iostream>
#include <random>
#include <vector>
using namespace std;

struct Stats {
    long long comparisons = 0;
    long long shifts = 0;
};

Stats insertionSort(vector<int> &arr) {
    Stats st;
    int n = static_cast<int>(arr.size());
    for (int i = 1; i < n; i++) {
        int key = arr[i];                          // the element to insert into arr[0..i-1]
        int j = i - 1;
        while (j >= 0) {
            st.comparisons++;
            if (arr[j] <= key) break;              // found its place (<= keeps equal elements stable)
            arr[j + 1] = arr[j];                   // shift the bigger element right
            st.shifts++;
            j--;
        }
        arr[j + 1] = key;
    }
    return st;
}

void printArray(const char *label, const vector<int> &a) {
    cout << label;
    for (size_t i = 0; i < a.size(); i++) {
        if (i > 0) cout << ' ';
        cout << a[i];
    }
    cout << '\n';
}

int main() {
    mt19937 gen(2024);                             // fixed seed: the same "random" data every run

    // 1. Small inputs: see the actual arrays.
    vector<int> sorted = {1, 2, 3, 4, 5, 6, 7, 8};
    vector<int> reversed = {8, 7, 6, 5, 4, 3, 2, 1};
    vector<int> randomSmall = {23, 42, 24, 63, 334, 53, 0, 43};
    for (auto *v : {&sorted, &reversed, &randomSmall}) {
        printArray("before: ", *v);
        insertionSort(*v);
        printArray("after:  ", *v);
    }

    // 2. Larger inputs: count the work.
    const int N = 1000;
    vector<int> s(N), r(N), rnd(N);
    for (int i = 0; i < N; i++) {
        s[i] = i;
        r[i] = N - i;
        rnd[i] = static_cast<int>(gen() % 100000);
    }
    cout << "\nn = " << N << '\n';
    for (auto &entry : {make_pair("sorted  ", &s), make_pair("reversed", &r), make_pair("random  ", &rnd)}) {
        Stats st = insertionSort(*entry.second);
        cout << entry.first << "  comparisons = " << st.comparisons << ", shifts = " << st.shifts
             << ", sorted correctly: " << (is_sorted(entry.second->begin(), entry.second->end()) ? "yes" : "NO") << '\n';
    }
    return 0;
}
