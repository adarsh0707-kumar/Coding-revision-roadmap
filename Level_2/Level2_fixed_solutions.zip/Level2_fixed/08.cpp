/*
8. Remove Duplicates from a Sorted Array

Modify a sorted array in place so each distinct value appears once.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 08.cpp -o program
*/

#include <iostream>
#include <iterator>
using namespace std;

// Input MUST be sorted. Returns the number of distinct values (new length).
int removeDuplicates(int arr[], int n) {
    if (n == 0) return 0;
    int k = 1;                              // arr[0] is always unique
    for (int i = 1; i < n; i++) {
        if (arr[i] != arr[k - 1]) {         // different from the last kept value
            arr[k] = arr[i];
            k++;
        }
    }
    return k;
}

void printFirst(const int arr[], int k) {
    for (int i = 0; i < k; i++) {
        if (i > 0) cout << ' ';
        cout << arr[i];
    }
    cout << '\n';
}

int main() {
    int a[] = {0, 0, 2, 3, 3, 4, 4, 6, 22, 22, 33, 84, 84, 204};
    int b[] = {1, 1, 1, 1};
    int c[] = {1, 2, 3};
    int d[] = {5};

    int k = removeDuplicates(a, static_cast<int>(size(a))); printFirst(a, k);
    k = removeDuplicates(b, static_cast<int>(size(b)));     printFirst(b, k);
    k = removeDuplicates(c, static_cast<int>(size(c)));     printFirst(c, k);
    k = removeDuplicates(d, static_cast<int>(size(d)));     printFirst(d, k);
    cout << "Empty -> new length " << removeDuplicates(a, 0) << '\n';
    return 0;
}
