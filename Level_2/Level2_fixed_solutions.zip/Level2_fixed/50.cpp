/*
50. Two Sum

Given an integer array and a target, find two distinct elements whose sum equals the target. Try brute force first, then improve with `std::unordered_map`.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 50.cpp -o program
*/

#include <iostream>
#include <optional>
#include <unordered_map>
#include <vector>
using namespace std;

struct IndexPair {
    size_t first, second;
};

// 1. Brute force: try every pair. O(n^2) time, O(1) space.
optional<IndexPair> twoSumBrute(const vector<int> &a, long long target) {
    for (size_t i = 0; i < a.size(); i++)
        for (size_t j = i + 1; j < a.size(); j++)
            if (static_cast<long long>(a[i]) + a[j] == target)   // long long: no int overflow
                return IndexPair{i, j};
    return nullopt;
}

// 2. One pass with a hash map: O(n) time, O(n) space.
optional<IndexPair> twoSumHash(const vector<int> &a, long long target) {
    unordered_map<long long, size_t> seen;                       // value -> index of an earlier element
    for (size_t i = 0; i < a.size(); i++) {
        long long complement = target - a[i];
        auto it = seen.find(complement);
        if (it != seen.end()) return IndexPair{it->second, i};   // partner was seen before i
        seen[a[i]] = i;                                          // store AFTER checking: distinct indices
    }
    return nullopt;
}

// 3. EVERY pair, duplicates handled correctly: keep all earlier indices of each value.
vector<IndexPair> allPairs(const vector<int> &a, long long target) {
    unordered_map<long long, vector<size_t>> seen;
    vector<IndexPair> pairs;
    for (size_t i = 0; i < a.size(); i++) {
        auto it = seen.find(target - a[i]);
        if (it != seen.end())
            for (size_t j : it->second) pairs.push_back({j, i});
        seen[a[i]].push_back(i);
    }
    return pairs;
}

int main() {
    int n;
    cout << "Enter the number of elements: ";
    if (!(cin >> n) || n < 0) {
        cout << "Invalid size\n";
        return 1;
    }
    vector<int> a(n);
    cout << "Enter " << n << " integers: ";
    for (int &x : a) {
        if (!(cin >> x)) {
            cout << "Invalid input\n";
            return 1;
        }
    }
    long long target;
    cout << "Enter the target: ";
    if (!(cin >> target)) {
        cout << "Invalid input\n";
        return 1;
    }

    auto describe = [&](const char *label, optional<IndexPair> p) {
        cout << label;
        if (p) cout << a[p->first] << " + " << a[p->second] << " = " << target
                    << " (indices " << p->first << " and " << p->second << ")\n";
        else   cout << "no pair\n";
    };
    describe("Brute force, first pair: ", twoSumBrute(a, target));
    describe("Hash map, first pair:    ", twoSumHash(a, target));

    auto pairs = allPairs(a, target);
    cout << "All pairs: " << pairs.size() << '\n';
    for (const auto &p : pairs)
        cout << "  " << a[p.first] << " + " << a[p.second] << " (indices " << p.first << ", " << p.second << ")\n";
    return 0;
}
