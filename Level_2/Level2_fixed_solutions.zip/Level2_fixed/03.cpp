/*
3. Calculate Array Sum and Average

Calculate the sum and average of all elements.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 03.cpp -o program
*/

#include <iostream>
#include <iterator>
using namespace std;

long long arraySum(const int arr[], int n) {
    long long sum = 0;                         // wide accumulator
    for (int i = 0; i < n; i++)
        sum += arr[i];
    return sum;
}

bool arrayAverage(const int arr[], int n, double &avg) {
    if (n <= 0) return false;                  // would divide by zero
    avg = static_cast<double>(arraySum(arr, n)) / n;
    return true;
}

int main() {
    int a[] = {1, 3, 4, 5, 9, 4, 6, 33, 0, 3, -4};
    int big[] = {2000000000, 2000000000, 2000000000};   // sum 6e9 does not fit in int

    cout << "Sum: " << arraySum(a, static_cast<int>(size(a))) << '\n';

    double avg;
    if (arrayAverage(a, static_cast<int>(size(a)), avg)) cout << "Average: " << avg << '\n';

    cout << "Big sum: " << arraySum(big, static_cast<int>(size(big))) << '\n';
    if (!arrayAverage(a, 0, avg)) cout << "Empty array: average undefined\n";
    return 0;
}
