/*
5. Find the Second-Largest Element

Find the second-largest **distinct** element without sorting.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 05.cpp -o program
*/

#include <iostream>
#include <iterator>
using namespace std;

// Returns false if there is no second-largest DISTINCT value.
bool secondLargest(const int arr[], int n, int &result) {
    if (n < 2) return false;

    int first = arr[0];
    int second = 0;
    bool hasSecond = false;

    for (int i = 1; i < n; i++) {
        int x = arr[i];
        if (x > first) {
            second = first;                 // old maximum is now the runner-up
            hasSecond = true;
            first = x;
        } else if (x < first && (!hasSecond || x > second)) {
            second = x;
            hasSecond = true;
        }                                   // x == first: duplicate, ignore
    }

    if (!hasSecond) return false;
    result = second;
    return true;
}

static void test(const char *label, const int arr[], int n) {
    int r;
    cout << label << " -> ";
    if (secondLargest(arr, n, r)) cout << r << '\n';
    else                          cout << "no second largest\n";
}

int main() {
    int a[] = {0, 3, 1, 9, 5, 7, 4, 6, 8, 9};
    int b[] = {9, 9, 5};
    int c[] = {7, 7, 7};
    int d[] = {5, -2147483647 - 1};         // contains INT_MIN as a real value
    int e[] = {-3, -7};
    int f[] = {1};

    test("{0,3,1,9,5,7,4,6,8,9}", a, static_cast<int>(size(a)));
    test("{9,9,5}", b, static_cast<int>(size(b)));
    test("{7,7,7}", c, static_cast<int>(size(c)));
    test("{5,INT_MIN}", d, static_cast<int>(size(d)));
    test("{-3,-7}", e, static_cast<int>(size(e)));
    test("{1}", f, static_cast<int>(size(f)));
    return 0;
}
