/*
42. Merge Two Sorted Arrays

Merge two sorted arrays into one sorted array.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 42.cpp -o program
*/

#include <iostream>
#include <vector>
using namespace std;

// Merges two ascending vectors into a new ascending vector. O(n + m) time.
vector<int> mergeSorted(const vector<int> &a, const vector<int> &b) {
    vector<int> result;
    result.reserve(a.size() + b.size());              // avoid re-allocations

    size_t i = 0, j = 0;
    while (i < a.size() && j < b.size()) {
        if (a[i] <= b[j]) result.push_back(a[i++]);   // <= : on ties take from `a` first (stable)
        else              result.push_back(b[j++]);
    }
    while (i < a.size()) result.push_back(a[i++]);    // one of these two loops does nothing
    while (j < b.size()) result.push_back(b[j++]);
    return result;
}

bool readSortedArray(const char *name, vector<int> &out) {
    int n;
    cout << "Enter the size of " << name << ": ";
    if (!(cin >> n) || n < 0) return false;
    out.assign(n, 0);
    cout << "Enter " << n << " integers in ascending order: ";
    for (int &x : out)
        if (!(cin >> x)) return false;
    for (int i = 1; i < n; i++)
        if (out[i - 1] > out[i]) {
            cout << name << " is not sorted\n";
            return false;
        }
    return true;
}

int main() {
    vector<int> a, b;
    if (!readSortedArray("the first array", a) || !readSortedArray("the second array", b)) {
        cout << "Invalid input\n";
        return 1;
    }

    vector<int> merged = mergeSorted(a, b);
    cout << "Merged:";
    for (int x : merged) cout << ' ' << x;
    cout << '\n';
    return 0;
}
