/*
29. Dynamic Memory Allocation

Allocate an array with `new[]`, initialize it, print it, and release it correctly.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 29.cpp -o program
*/

#include <iostream>
#include <new>
using namespace std;

int main() {
    int n;
    cout << "Enter array size: ";
    if (!(cin >> n) || n <= 0) {
        cout << "Invalid array size\n";
        return 1;
    }

    int *arr = nullptr;
    try {
        arr = new int[n]();                          // () zero-initialises every element
    } catch (const bad_alloc &) {
        cout << "Memory allocation failed\n";
        return 1;
    }

    cout << "Freshly allocated (zero-initialised): ";
    for (int i = 0; i < n; i++) cout << arr[i] << ' ';
    cout << '\n';

    cout << "Enter " << n << " integers: ";
    for (int i = 0; i < n; i++) {
        if (!(cin >> arr[i])) {
            cout << "Invalid or missing input\n";
            delete[] arr;                            // free on the error path too
            return 1;
        }
    }

    cout << "Values: ";
    for (int i = 0; i < n; i++) cout << arr[i] << ' ';
    cout << '\n';

    delete[] arr;                                    // new[] -> delete[]
    arr = nullptr;                                   // no dangling pointer left behind
    return 0;
}
