/*
4. Reverse an Array

Reverse an array in place, without a second array.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 04.cpp -o program
*/

#include <iostream>
#include <iterator>
#include <utility>        // std::swap
using namespace std;

void reverseArray(int arr[], int n) {
    int left = 0, right = n - 1;
    while (left < right) {                // strict <: the middle element stays put
        swap(arr[left], arr[right]);      // safe for any values, no overflow
        left++;
        right--;
    }
}

void printArray(const int arr[], int n) {
    for (int i = 0; i < n; i++) {
        if (i > 0) cout << ' ';
        cout << arr[i];
    }
    cout << '\n';
}

int main() {
    int a[] = {1, 3, 4, 5, 9, 4, 6, 34, 0, 3};   // even length
    int b[] = {1, 2, 3, 4, 5};                   // odd length
    int c[] = {7};
    int big[] = {2147483647, 1};                 // your arithmetic swap breaks here

    reverseArray(a, static_cast<int>(size(a)));   printArray(a, static_cast<int>(size(a)));
    reverseArray(b, static_cast<int>(size(b)));   printArray(b, static_cast<int>(size(b)));
    reverseArray(c, static_cast<int>(size(c)));   printArray(c, static_cast<int>(size(c)));
    reverseArray(big, static_cast<int>(size(big))); printArray(big, static_cast<int>(size(big)));
    reverseArray(a, 0);                          // empty: nothing happens
    return 0;
}
