/*
35. Calculate Power Recursively

Calculate `a^b` recursively for a non-negative exponent.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 35.cpp -o program
*/

#include <climits>
#include <iomanip>
#include <iostream>
using namespace std;

// result = a * b, or false if the product does not fit in a long long.
bool safeMultiply(long long a, long long b, long long &result) {
    if (a > 0) {
        if (b > 0) { if (a > LLONG_MAX / b) return false; }
        else       { if (b < LLONG_MIN / a) return false; }
    } else if (a < 0) {
        if (b > 0) { if (a < LLONG_MIN / b) return false; }
        else       { if (b < LLONG_MAX / a) return false; }
    }
    result = a * b;
    return true;
}

// Integer power by repeated halving. Returns false on overflow.
bool powerInt(long long base, unsigned long long exp, long long &result) {
    if (exp == 0) {                                  // base case: a^0 = 1 (including 0^0)
        result = 1;
        return true;
    }
    long long half;
    if (!powerInt(base, exp / 2, half)) return false;    // computed ONCE and reused

    long long square;
    if (!safeMultiply(half, half, square)) return false;

    if (exp % 2 == 0) {
        result = square;
        return true;
    }
    return safeMultiply(square, base, result);           // odd exponent: one extra factor
}

// Real-number version (your original idea).
double powerDouble(double x, unsigned long long n) {
    if (n == 0) return 1.0;
    double half = powerDouble(x, n / 2);
    return (n % 2 == 0) ? half * half : x * half * half;
}

int main() {
    long long base, exponent;
    cout << "Enter an integer base and a non-negative exponent: ";
    if (!(cin >> base >> exponent)) {
        cout << "Invalid input\n";
        return 1;
    }
    if (exponent < 0) {
        cout << "Negative exponent is not allowed\n";
        return 1;
    }

    long long result;
    if (powerInt(base, static_cast<unsigned long long>(exponent), result))
        cout << base << "^" << exponent << " = " << result << '\n';
    else
        cout << base << "^" << exponent << " does not fit in a long long (overflow)\n";

    cout << setprecision(10)
         << "Real-number examples: 2.5^3 = " << powerDouble(2.5, 3)
         << ", 2^20 = " << powerDouble(2, 20) << '\n';
    return 0;
}
