/*
16. Check Anagrams

Decide whether two strings contain the same characters with the same frequencies.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 16.cpp -o program
*/

#include <cctype>
#include <iostream>
#include <string>
using namespace std;

// Strict: case-sensitive, spaces count.
bool isAnagram(const string &a, const string &b) {
    if (a.size() != b.size()) return false;

    int count[256] = {};
    for (size_t i = 0; i < a.size(); i++) {
        count[static_cast<unsigned char>(a[i])]++;
        count[static_cast<unsigned char>(b[i])]--;
    }
    for (int c : count)
        if (c != 0) return false;
    return true;
}

// Relaxed: ignore case and anything that is not a letter or digit.
bool isAnagramRelaxed(const string &a, const string &b) {
    int count[256] = {};
    for (char ch : a)
        if (isalnum(static_cast<unsigned char>(ch)))
            count[tolower(static_cast<unsigned char>(ch))]++;
    for (char ch : b)
        if (isalnum(static_cast<unsigned char>(ch)))
            count[tolower(static_cast<unsigned char>(ch))]--;
    for (int c : count)
        if (c != 0) return false;
    return true;
}

int main() {
    string a, b;
    cout << "Enter the first string: ";
    getline(cin, a);
    cout << "Enter the second string: ";
    if (!getline(cin, b)) {
        cout << "Need two lines of input\n";
        return 0;
    }

    cout << "Strict:  " << (isAnagram(a, b) ? "anagrams" : "not anagrams") << '\n';
    cout << "Relaxed: " << (isAnagramRelaxed(a, b) ? "anagrams" : "not anagrams") << '\n';
    return 0;
}
