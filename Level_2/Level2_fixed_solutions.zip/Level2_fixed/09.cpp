/*
9. Rotate an Array

Rotate an array to the right (and left) by `k` positions.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 09.cpp -o program
*/

#include <iostream>
#include <iterator>
#include <utility>
using namespace std;

void reverseRange(int arr[], int start, int end) {
    while (start < end) {
        swap(arr[start], arr[end]);
        start++;
        end--;
    }
}

// Maps ANY k (negative, or >= n) into the range [0, n-1].
int normalize(int k, int n) {
    return ((k % n) + n) % n;
}

void rotateRight(int arr[], int n, int k) {
    if (n <= 0) return;
    k = normalize(k, n);
    if (k == 0) return;               // nothing to do; the array stays as it is
    reverseRange(arr, 0, n - 1);      // 1. reverse everything
    reverseRange(arr, 0, k - 1);      // 2. fix the first k elements
    reverseRange(arr, k, n - 1);      // 3. fix the remaining n-k elements
}

void rotateLeft(int arr[], int n, int k) {
    if (n <= 0) return;
    k = normalize(k, n);
    if (k == 0) return;
    reverseRange(arr, 0, k - 1);      // 1. reverse the first k
    reverseRange(arr, k, n - 1);      // 2. reverse the rest
    reverseRange(arr, 0, n - 1);      // 3. reverse everything
}

void printArray(const char *label, const int arr[], int n) {
    cout << label;
    for (int i = 0; i < n; i++) {
        if (i > 0) cout << ' ';
        cout << arr[i];
    }
    cout << '\n';
}

int main() {
    const int base[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
    const int n = static_cast<int>(size(base));
    const int ks[] = {3, 13, 10, 0, 1, -1};

    for (int k : ks) {
        int a[n];
        int b[n];
        for (int i = 0; i < n; i++) { a[i] = base[i]; b[i] = base[i]; }

        rotateLeft(a, n, k);
        rotateRight(b, n, k);

        cout << "k = " << k << '\n';
        printArray("  left : ", a, n);
        printArray("  right: ", b, n);
    }

    int one[] = {42};
    rotateRight(one, 1, 5);
    printArray("single element: ", one, 1);
    rotateLeft(one, 0, 5);              // empty array: nothing happens
    return 0;
}
