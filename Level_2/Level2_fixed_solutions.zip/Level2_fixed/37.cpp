/*
37. Tower of Hanoi

Print the steps to move `n` disks from one rod to another using a third rod, following the rules (move one disk at a time; never place a larger disk on a smaller one).

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 37.cpp -o program
*/

#include <iostream>
using namespace std;

// Prints the moves and returns how many there were.
unsigned long long hanoi(int n, char from, char to, char via) {
    if (n == 0) return 0;                                           // base case: nothing to move

    unsigned long long moves = hanoi(n - 1, from, via, to);         // 1. n-1 disks: from -> via
    cout << "Move disk " << n << " from " << from << " to " << to << '\n';   // 2. the largest disk
    moves++;
    moves += hanoi(n - 1, via, to, from);                           // 3. n-1 disks: via -> to
    return moves;
}

int main() {
    int n;
    cout << "Enter the number of disks (1 to 20): ";
    if (!(cin >> n) || n < 1 || n > 20) {
        cout << "Invalid input: enter a number from 1 to 20 (2^n - 1 moves are printed)\n";
        return 1;
    }

    unsigned long long moves = hanoi(n, 'A', 'C', 'B');
    cout << "Total moves: " << moves << '\n';
    return 0;
}
