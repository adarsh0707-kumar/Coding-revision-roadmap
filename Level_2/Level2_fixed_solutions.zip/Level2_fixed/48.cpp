/*
48. Remove Duplicates Using std::set

Remove duplicate values from a collection and print the unique values in sorted order.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 48.cpp -o program
*/

#include <algorithm>
#include <iostream>
#include <set>
#include <unordered_set>
#include <vector>
using namespace std;

void printValues(const char *label, const vector<int> &v) {
    cout << label;
    for (int x : v) cout << ' ' << x;
    cout << '\n';
}

int main() {
    int n;
    cout << "Enter the number of elements: ";
    if (!(cin >> n) || n < 0) {
        cout << "Invalid size\n";
        return 1;
    }
    vector<int> numbers(n);
    cout << "Enter " << n << " integers: ";
    for (int &x : numbers) {
        if (!(cin >> x)) {
            cout << "Invalid input\n";
            return 1;
        }
    }

    // 1. std::set: unique AND sorted automatically. O(n log n).
    set<int> unique(numbers.begin(), numbers.end());
    cout << "std::set:             ";
    for (int x : unique) cout << x << ' ';
    cout << '\n';

    // 2. sort + std::unique on a copy: same result, contiguous memory (usually faster). O(n log n).
    vector<int> sorted = numbers;
    sort(sorted.begin(), sorted.end());
    sorted.erase(std::unique(sorted.begin(), sorted.end()), sorted.end());
    printValues("sort + unique:        ", sorted);

    // 3. unordered_set to drop duplicates in O(n), then sort the survivors.
    unordered_set<int> seen(numbers.begin(), numbers.end());
    vector<int> viaHash(seen.begin(), seen.end());
    sort(viaHash.begin(), viaHash.end());
    printValues("unordered_set + sort: ", viaHash);

    cout << "Unique values: " << unique.size() << " of " << numbers.size() << '\n';
    return 0;
}
