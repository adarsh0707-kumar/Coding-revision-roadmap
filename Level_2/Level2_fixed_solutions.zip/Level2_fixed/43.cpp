/*
43. Merge Sort

Implement merge sort using divide and conquer.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 43.cpp -o program
*/

#include <algorithm>
#include <iostream>
#include <random>
#include <vector>
using namespace std;

// Merges the sorted halves a[left..mid] and a[mid+1..right] using the shared buffer.
void mergeHalves(vector<int> &a, vector<int> &buffer, int left, int mid, int right) {
    copy(a.begin() + left, a.begin() + right + 1, buffer.begin() + left);

    int i = left, j = mid + 1, k = left;
    while (i <= mid && j <= right) {
        if (buffer[i] <= buffer[j]) a[k++] = buffer[i++];   // <= keeps the sort stable
        else                        a[k++] = buffer[j++];
    }
    while (i <= mid) a[k++] = buffer[i++];
    // Any remaining right-half elements are already in their final place.
}

void mergeSortRange(vector<int> &a, vector<int> &buffer, int left, int right) {
    if (left >= right) return;                      // base case: 0 or 1 element is sorted
    int mid = left + (right - left) / 2;
    mergeSortRange(a, buffer, left, mid);           // divide ...
    mergeSortRange(a, buffer, mid + 1, right);
    mergeHalves(a, buffer, left, mid, right);       // ... and conquer (combine)
}

void mergeSort(vector<int> &a) {
    if (a.size() < 2) return;
    vector<int> buffer(a.size());                   // ONE auxiliary array for the whole sort
    mergeSortRange(a, buffer, 0, static_cast<int>(a.size()) - 1);
}

int main() {
    vector<int> arr = {38, 27, 43, 3, 9, 82, 10};
    cout << "Original:";
    for (int x : arr) cout << ' ' << x;
    mergeSort(arr);
    cout << "\nSorted:  ";
    for (int x : arr) cout << ' ' << x;
    cout << '\n';

    mt19937 gen(5);
    int failures = 0;
    for (int t = 0; t < 2000; t++) {
        vector<int> v(gen() % 80);
        for (int &x : v) x = static_cast<int>(gen() % 41) - 20;
        vector<int> expected = v;
        sort(expected.begin(), expected.end());
        mergeSort(v);
        if (v != expected) failures++;
    }
    cout << "Self-test against std::sort (2000 random arrays): " << (failures == 0 ? "passed" : "FAILED") << '\n';

    vector<int> big(1000000);
    for (int &x : big) x = static_cast<int>(gen());
    mergeSort(big);
    cout << "1,000,000 random integers sorted: " << (is_sorted(big.begin(), big.end()) ? "ok" : "NO") << '\n';
    return 0;
}
