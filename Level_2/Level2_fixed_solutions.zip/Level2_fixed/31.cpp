/*
31. Factorial Using Recursion

Calculate the factorial of a non-negative integer recursively.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 31.cpp -o program
*/

#include <iostream>
using namespace std;

// Precondition: 0 <= n <= 20 (checked by factorial() below).
unsigned long long factorialRec(int n) {
    if (n <= 1) return 1;                                      // base case: 0! = 1! = 1
    return static_cast<unsigned long long>(n) * factorialRec(n - 1);
}

// Safe entry point: returns false when the result would not exist or not fit.
bool factorial(int n, unsigned long long &result) {
    if (n < 0 || n > 20) return false;                         // 21! > ULLONG_MAX
    result = factorialRec(n);
    return true;
}

int main() {
    int n;
    cout << "Enter a non-negative integer: ";
    if (!(cin >> n)) {
        cout << "Invalid input\n";
        return 1;
    }

    unsigned long long result;
    if (factorial(n, result))
        cout << n << "! = " << result << '\n';
    else if (n < 0)
        cout << "Factorial is not defined for negative numbers\n";
    else
        cout << "Overflow: " << n << "! does not fit in unsigned long long (maximum n is 20)\n";
    return 0;
}
