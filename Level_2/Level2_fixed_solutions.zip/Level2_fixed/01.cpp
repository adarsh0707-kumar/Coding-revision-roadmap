/*
1. Find the Largest Element

Find the largest element of an integer array without sorting.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 01.cpp -o program
*/

#include <iostream>
#include <iterator>
using namespace std;

// Returns false if the array is empty; otherwise stores the maximum in `result`.
bool findLargest(const int arr[], int n, int &result) {
    if (n <= 0) return false;
    int largest = arr[0];                    // start from a REAL element
    for (int i = 1; i < n; i++)
        if (arr[i] > largest)
            largest = arr[i];
    result = largest;
    return true;
}

int main() {
    int a[] = {1, 3, 4, 5, 9, 4, 6, 4, 0, 3};
    int b[] = {-8, -3, -20};
    int c[] = {42};

    int result;
    if (findLargest(a, static_cast<int>(size(a)), result)) cout << "Largest: " << result << '\n';
    if (findLargest(b, static_cast<int>(size(b)), result)) cout << "Largest: " << result << '\n';
    if (findLargest(c, static_cast<int>(size(c)), result)) cout << "Largest: " << result << '\n';
    if (!findLargest(a, 0, result)) cout << "Empty array: no largest element\n";
    return 0;
}
