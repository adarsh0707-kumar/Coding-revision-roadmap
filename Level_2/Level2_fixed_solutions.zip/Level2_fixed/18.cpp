/*
18. First Non-Repeating Character

Find the first character that appears exactly once.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 18.cpp -o program
*/

#include <iostream>
#include <optional>
#include <string>
using namespace std;

optional<char> firstNonRepeating(const string &s) {
    int freq[256] = {};
    for (char ch : s)
        freq[static_cast<unsigned char>(ch)]++;

    for (char ch : s)
        if (freq[static_cast<unsigned char>(ch)] == 1)
            return ch;                      // implicitly wraps the char in an optional

    return nullopt;                         // "no value"
}

int main() {
    string s;
    cout << "Enter a string: ";
    if (!getline(cin, s)) {
        cout << "No input\n";
        return 0;
    }

    auto result = firstNonRepeating(s);
    if (result)
        cout << "First non-repeating character: " << *result << '\n';
    else
        cout << "No non-repeating character\n";
    return 0;
}
