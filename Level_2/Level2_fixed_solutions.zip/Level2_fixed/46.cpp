/*
46. Matrix Multiplication

Multiply two matrices when their dimensions are compatible.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 46.cpp -o program
*/

#include <iostream>
#include <stdexcept>
#include <vector>
using namespace std;

using Matrix = vector<vector<long long>>;

bool readMatrix(const char *name, Matrix &m) {
    int rows, cols;
    cout << "Enter the number of rows and columns of " << name << ": ";
    if (!(cin >> rows >> cols) || rows < 1 || cols < 1) return false;
    m.assign(rows, vector<long long>(cols));
    cout << "Enter " << rows << " x " << cols << " values, row by row: ";
    for (auto &row : m)
        for (long long &x : row)
            if (!(cin >> x)) return false;
    return true;
}

void printMatrix(const Matrix &m) {
    for (const auto &row : m) {
        for (size_t j = 0; j < row.size(); j++) {
            if (j > 0) cout << ' ';
            cout << row[j];
        }
        cout << '\n';
    }
}

// (r1 x c1) times (r2 x c2) is defined only when c1 == r2; the result is r1 x c2.
Matrix multiply(const Matrix &a, const Matrix &b) {
    size_t r1 = a.size(), c1 = a[0].size(), r2 = b.size(), c2 = b[0].size();
    if (c1 != r2)
        throw invalid_argument("columns of A (" + to_string(c1) + ") must equal rows of B (" + to_string(r2) + ")");

    Matrix product(r1, vector<long long>(c2, 0));
    for (size_t i = 0; i < r1; i++)
        for (size_t k = 0; k < c1; k++)                 // i-k-j order walks both matrices row by row
            for (size_t j = 0; j < c2; j++)
                product[i][j] += a[i][k] * b[k][j];
    return product;
}

int main() {
    Matrix a, b;
    if (!readMatrix("matrix A", a) || !readMatrix("matrix B", b)) {
        cout << "Invalid input\n";
        return 1;
    }

    try {
        cout << "\nA x B:\n";
        printMatrix(multiply(a, b));
    } catch (const invalid_argument &e) {
        cout << "Cannot multiply: " << e.what() << '\n';
    }
    return 0;
}
