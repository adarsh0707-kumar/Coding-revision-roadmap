/*
19. Build a Calculator Using Functions

Implement `+ - * /` in separate functions and use them.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 19.cpp -o program
*/

#include <iostream>
using namespace std;

long long add(int a, int b)      { return static_cast<long long>(a) + b; }
long long subtract(int a, int b) { return static_cast<long long>(a) - b; }
long long multiply(int a, int b) { return static_cast<long long>(a) * b; }

// Returns false when the division is impossible.
bool divide(int a, int b, double &result) {
    if (b == 0) return false;
    result = static_cast<double>(a) / b;
    return true;
}

int main() {
    int a, b;
    char op;
    cout << "Enter an expression (e.g. 3 + 4): ";
    if (!(cin >> a >> op >> b)) {
        cout << "Invalid input\n";
        return 1;
    }

    switch (op) {
    case '+': cout << a << " + " << b << " = " << add(a, b) << '\n'; break;
    case '-': cout << a << " - " << b << " = " << subtract(a, b) << '\n'; break;
    case '*': cout << a << " * " << b << " = " << multiply(a, b) << '\n'; break;
    case '/': {
        double result;
        if (divide(a, b, result)) cout << a << " / " << b << " = " << result << '\n';
        else                      cout << "Error: division by zero\n";
        break;
    }
    default:
        cout << "Error: invalid operator '" << op << "'\n";
    }
    return 0;
}
