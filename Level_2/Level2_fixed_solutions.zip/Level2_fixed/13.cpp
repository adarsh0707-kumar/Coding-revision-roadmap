/*
13. Count Vowels and Consonants

Count vowels and consonants, handling upper and lower case.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 13.cpp -o program
*/

#include <cctype>
#include <iostream>
#include <string>
using namespace std;

bool isVowel(char c) {
    char lower = static_cast<char>(tolower(static_cast<unsigned char>(c)));
    return lower == 'a' || lower == 'e' || lower == 'i' || lower == 'o' || lower == 'u';
}

void countVowelsAndConsonants(const string &s, int &vowels, int &consonants) {
    vowels = 0;
    consonants = 0;
    for (char c : s) {
        if (!isalpha(static_cast<unsigned char>(c))) continue;   // ignore non-letters
        if (isVowel(c)) vowels++;
        else            consonants++;
    }
}

int main() {
    string s;
    cout << "Enter a string: ";
    if (!getline(cin, s)) {
        cout << "No input\n";
        return 0;
    }

    int vowels, consonants;
    countVowelsAndConsonants(s, vowels, consonants);
    cout << "Vowels: " << vowels << '\n';
    cout << "Consonants: " << consonants << '\n';
    return 0;
}
