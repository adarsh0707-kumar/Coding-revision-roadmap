/*
20. GCD and LCM Functions

Implement separate GCD and LCM functions for two integers.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 20.cpp -o program
*/

#include <iostream>
#include <limits>
#include <optional>
using namespace std;

using ULL = unsigned long long;

// |n| as an unsigned value. Safe even for LLONG_MIN.
ULL magnitude(long long n) {
    return n < 0 ? static_cast<ULL>(-(n + 1)) + 1 : static_cast<ULL>(n);
}

ULL gcdValue(ULL a, ULL b) {
    while (b != 0) {
        ULL r = a % b;
        a = b;
        b = r;
    }
    return a;
}

// nullopt when the LCM does not fit in a long long.
optional<long long> lcmValue(long long a, long long b) {
    ULL x = magnitude(a);
    ULL y = magnitude(b);
    if (x == 0 || y == 0) return 0LL;

    ULL g = gcdValue(x, y);
    ULL reduced = x / g;                                   // divide first

    const ULL maxValue = static_cast<ULL>(numeric_limits<long long>::max());
    if (reduced > maxValue / y) return nullopt;            // reduced * y would not fit

    return static_cast<long long>(reduced * y);
}

int main() {
    long long a, b;
    cout << "Enter two integers: ";
    if (!(cin >> a >> b)) {
        cout << "Invalid input\n";
        return 1;
    }

    cout << "GCD(" << a << ", " << b << ") = " << gcdValue(magnitude(a), magnitude(b)) << '\n';

    auto l = lcmValue(a, b);
    if (l) cout << "LCM(" << a << ", " << b << ") = " << *l << '\n';
    else   cout << "LCM exceeds the long long range\n";
    return 0;
}
