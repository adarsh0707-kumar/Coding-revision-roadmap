/*
39. Bubble Sort

Sort an array in ascending order using bubble sort.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 39.cpp -o program
*/

#include <iostream>
#include <utility>
#include <vector>
using namespace std;

// Returns the number of comparisons made.
long long bubbleSort(vector<int> &arr) {
    long long comparisons = 0;
    int n = static_cast<int>(arr.size());
    for (int i = 0; i < n - 1; i++) {
        bool swapped = false;                      // did this pass change anything?
        for (int j = 0; j < n - i - 1; j++) {
            comparisons++;
            if (arr[j] > arr[j + 1]) {             // strict >: equal elements never swap (stable)
                swap(arr[j], arr[j + 1]);
                swapped = true;
            }
        }
        if (!swapped) break;                       // already sorted: stop early
    }
    return comparisons;
}

void printArray(const char *label, const vector<int> &a) {
    cout << label;
    for (size_t i = 0; i < a.size(); i++) {
        if (i > 0) cout << ' ';
        cout << a[i];
    }
    cout << '\n';
}

int main() {
    int n;
    cout << "Enter the number of elements: ";
    if (!(cin >> n) || n < 0) {
        cout << "Invalid size\n";
        return 1;
    }
    vector<int> arr(n);
    cout << "Enter " << n << " integers: ";
    for (int &x : arr) {
        if (!(cin >> x)) {
            cout << "Invalid input\n";
            return 1;
        }
    }

    printArray("Original: ", arr);
    long long comparisons = bubbleSort(arr);
    printArray("Sorted:   ", arr);
    cout << "Comparisons: " << comparisons << '\n';
    return 0;
}
