/*
14. Count Words in a Sentence

Count words, handling repeated spaces and leading or trailing whitespace.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 14.cpp -o program
*/

#include <cctype>
#include <iostream>
#include <sstream>
#include <string>
using namespace std;

int countWords(const string &s) {
    int count = 0;
    bool inWord = false;
    for (char c : s) {
        if (isspace(static_cast<unsigned char>(c))) {
            inWord = false;                    // whitespace ends any current word
        } else if (!inWord) {
            inWord = true;                     // a new word begins here
            count++;
        }
    }
    return count;
}

// Same result with the standard library: `>>` skips whitespace automatically.
int countWordsStream(const string &s) {
    istringstream in(s);
    string word;
    int count = 0;
    while (in >> word) count++;
    return count;
}

int main() {
    string s;
    cout << "Enter a sentence: ";
    if (!getline(cin, s)) {
        cout << "No input\n";
        return 0;
    }

    cout << "Words: " << countWords(s) << '\n';
    cout << "Words (stream check): " << countWordsStream(s) << '\n';
    return 0;
}
