/*
24. Function Overloading

Create overloaded functions that compute the area of a circle, a rectangle and a square.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 24.cpp -o program
*/

#include <iostream>
using namespace std;

enum class Shape { Square };                       // a tag type, no implicit conversions

const double PI = 3.14159265358979323846;

double area(double radius) {                       // circle
    return PI * radius * radius;
}

double area(double length, double breadth) {       // rectangle
    return length * breadth;
}

double area(double side, Shape) {                  // square (the tag disambiguates)
    return side * side;
}

int main() {
    double r, side, length, breadth;

    cout << "Enter radius of the circle: ";
    cin >> r;
    cout << "Enter side of the square: ";
    cin >> side;
    cout << "Enter length and breadth of the rectangle: ";
    cin >> length >> breadth;

    if (!cin || r < 0 || side < 0 || length < 0 || breadth < 0) {
        cout << "Error: enter non-negative numbers only\n";
        return 1;
    }

    cout << "Circle:    " << area(r) << '\n';
    cout << "Square:    " << area(side, Shape::Square) << '\n';
    cout << "Rectangle: " << area(length, breadth) << '\n';
    return 0;
}
