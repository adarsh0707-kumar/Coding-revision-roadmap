/*
33. Sum of Digits Using Recursion

Calculate the sum of an integer's digits recursively.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 33.cpp -o program
*/

#include <iostream>
using namespace std;

int sumOfDigits(unsigned int n) {
    if (n == 0) return 0;                       // base case: no digits left
    return static_cast<int>(n % 10) + sumOfDigits(n / 10);
}

int main() {
    int num;
    cout << "Enter an integer: ";
    if (!(cin >> num)) {
        cout << "Invalid input\n";
        return 1;
    }

    // |num| in unsigned arithmetic: well defined, and correct even for INT_MIN.
    unsigned int magnitude = (num < 0) ? 0u - static_cast<unsigned int>(num)
                                       : static_cast<unsigned int>(num);

    cout << "Sum of the digits of " << num << " is " << sumOfDigits(magnitude) << '\n';
    return 0;
}
