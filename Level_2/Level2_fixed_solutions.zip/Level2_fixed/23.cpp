/*
23. Swap Using References

Write a function that swaps two integers using reference parameters.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 23.cpp -o program
*/

#include <iostream>
#include <utility>
using namespace std;

void swapInts(int &a, int &b) {
    int temp = a;
    a = b;
    b = temp;
}

int main() {
    int x, y;
    cout << "Enter two integers: ";
    if (!(cin >> x >> y)) {
        cout << "Invalid input\n";
        return 1;
    }

    cout << "Before: x = " << x << ", y = " << y << '\n';
    swapInts(x, y);
    cout << "After:  x = " << x << ", y = " << y << '\n';

    int arr[] = {10, 20, 30};
    swapInts(arr[0], arr[2]);                 // works on any int lvalue
    cout << "Array after swapping the ends: " << arr[0] << ' ' << arr[1] << ' ' << arr[2] << '\n';

    swapInts(x, x);                           // same variable twice: still safe
    cout << "After swapInts(x, x): x = " << x << '\n';

    swap(x, y);                               // the standard library version (<utility>)
    cout << "After std::swap: x = " << x << ", y = " << y << '\n';
    return 0;
}
