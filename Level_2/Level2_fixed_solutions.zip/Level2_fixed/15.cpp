/*
15. Character Frequency

Count how many times each character occurs.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 15.cpp -o program
*/

#include <iostream>
#include <string>
using namespace std;

void printFrequency(const string &s) {
    int count[256] = {};                                  // one counter per possible byte
    for (char ch : s)
        count[static_cast<unsigned char>(ch)]++;

    bool first = true;
    for (char ch : s) {
        unsigned char u = static_cast<unsigned char>(ch);
        int c = count[u];
        if (c == 0) continue;                             // already printed

        if (!first) cout << ", ";
        if (ch == ' ') cout << "' '";                     // make spaces visible
        else           cout << ch;
        cout << ": " << c;

        count[u] = 0;                                     // never print this character again
        first = false;
    }
    cout << '\n';
}

int main() {
    string s;
    cout << "Enter a string: ";
    if (!getline(cin, s)) {
        cout << "No input\n";
        return 0;
    }
    printFrequency(s);
    return 0;
}
