/*
10. Move All Zeros to the End

Move all zeros to the end while keeping the order of the nonzero elements.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 10.cpp -o program
*/

#include <iostream>
#include <utility>
using namespace std;

void moveZerosToEnd(int arr[], int n) {
    int insertPos = 0;                           // next slot for a nonzero value
    for (int i = 0; i < n; i++) {
        if (arr[i] != 0) {
            if (i != insertPos)                  // skip pointless self-swaps
                swap(arr[i], arr[insertPos]);
            insertPos++;
        }
    }
}

void printArray(const int arr[], int n) {
    for (int i = 0; i < n; i++) {
        if (i > 0) cout << ' ';
        cout << arr[i];
    }
    cout << '\n';
}

int main() {
    int a[] = {0, 1, 0, 3, 13, 0, 8, 9};
    int b[] = {0, 0, 0};
    int c[] = {1, 2, 3};
    int d[] = {0, 1};
    int e[] = {0, 0, 1, 0, 2, 0, 0, 3};

    moveZerosToEnd(a, 8); printArray(a, 8);
    moveZerosToEnd(b, 3); printArray(b, 3);
    moveZerosToEnd(c, 3); printArray(c, 3);
    moveZerosToEnd(d, 2); printArray(d, 2);
    moveZerosToEnd(e, 8); printArray(e, 8);
    moveZerosToEnd(a, 0);                        // empty: nothing happens
    return 0;
}
