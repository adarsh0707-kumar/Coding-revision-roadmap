/*
17. Remove Duplicate Characters

Remove repeated characters, keeping the first occurrence of each.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 17.cpp -o program
*/

#include <iostream>
#include <string>
using namespace std;

string removeDuplicates(const string &s) {
    bool seen[256] = {};
    string result;
    for (char ch : s) {
        unsigned char u = static_cast<unsigned char>(ch);   // avoid negative indices
        if (!seen[u]) {
            seen[u] = true;
            result += ch;
        }
    }
    return result;
}

int main() {
    string s;
    cout << "Enter a string: ";
    if (!getline(cin, s)) {
        cout << "No input\n";
        return 0;
    }
    cout << "Result: " << removeDuplicates(s) << '\n';
    return 0;
}
