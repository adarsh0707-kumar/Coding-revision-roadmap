/*
49. Balanced Parentheses

Determine whether the brackets `()`, `{}`, `[]` in a string are correctly balanced, using `std::stack`.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 49.cpp -o program
*/

#include <iostream>
#include <stack>
#include <string>
#include <utility>
using namespace std;

bool isOpening(char c) { return c == '(' || c == '{' || c == '['; }
bool isClosing(char c) { return c == ')' || c == '}' || c == ']'; }
char matchingOpen(char close) { return close == ')' ? '(' : close == '}' ? '{' : '['; }

// Returns -1 if the brackets are balanced; otherwise the index where the problem is found:
// a closing bracket with no (or the wrong) partner, or the innermost unclosed opening bracket.
int findFirstError(const string &s) {
    stack<pair<char, int>> open;                       // (bracket, its index)
    for (int i = 0; i < static_cast<int>(s.size()); i++) {
        char c = s[i];
        if (isOpening(c)) {
            open.push({c, i});
        } else if (isClosing(c)) {
            if (open.empty() || open.top().first != matchingOpen(c))
                return i;                              // nothing to close, or closes the wrong kind
            open.pop();
        }                                              // every other character is ignored
    }
    return open.empty() ? -1 : open.top().second;
}

bool isBalanced(const string &s) { return findFirstError(s) == -1; }

int main() {
    cout << "Enter strings, one per line (Ctrl+D to stop):\n";
    string line;
    while (getline(cin, line)) {
        int err = findFirstError(line);
        cout << '"' << line << "\" -> ";
        if (err == -1) cout << "Balanced\n";
        else           cout << "Not balanced (problem at index " << err << ")\n";
    }
    return 0;
}
