/*
27. Traverse an Array Using Pointers

Print all elements using pointer arithmetic instead of array indexing.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 27.cpp -o program
*/

#include <iostream>
#include <iterator>
using namespace std;

void printWithPointers(const int *first, const int *last) {
    for (const int *p = first; p != last; ++p) {
        if (p != first) cout << ' ';
        cout << *p;
    }
    cout << '\n';
}

int main() {
    int arr[] = {0, 2, 1, 3, 5, 4, 6, 9, 8, 7};
    int n = static_cast<int>(size(arr));

    printWithPointers(arr, arr + n);                 // idiomatic: pointer to pointer range

    for (int i = 0; i < n; i++)                      // your version: base + offset
        cout << *(arr + i) << ' ';
    cout << '\n';

    for (const int *p = arr + n; p != arr;) {        // backwards: step first, then read
        --p;
        cout << *p << ' ';
    }
    cout << '\n';

    cout << "Index of the element holding 9: " << (arr + 7) - arr << '\n';   // pointer difference
    printWithPointers(arr, arr);                     // empty range prints just a newline
    return 0;
}
