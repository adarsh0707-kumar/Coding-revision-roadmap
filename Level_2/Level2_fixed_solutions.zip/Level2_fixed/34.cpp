/*
34. Reverse a String Recursively

Reverse a string using recursion, without a built-in reverse function.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 34.cpp -o program
*/

#include <iostream>
#include <string>
#include <utility>
using namespace std;

// Reverses s[left..right] in place.
void reverseHelper(string &s, int left, int right) {
    if (left >= right) return;                 // base case: 0 or 1 characters left
    swap(s[left], s[right]);                   // swap the two ends
    reverseHelper(s, left + 1, right - 1);     // reverse the middle part
}

void reverseString(string &s) {                // public entry point
    reverseHelper(s, 0, static_cast<int>(s.size()) - 1);
}

int main() {
    string s;
    cout << "Enter a string: ";
    if (!getline(cin, s)) {
        cout << "No input\n";
        return 0;
    }

    reverseString(s);
    cout << "Reversed: " << s << '\n';
    return 0;
}
