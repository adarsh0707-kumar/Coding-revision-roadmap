/*
40. Selection Sort

Sort an array using selection sort.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 40.cpp -o program
*/

#include <iostream>
#include <utility>
#include <vector>
using namespace std;

// Generic selection sort; `less(x, y)` says whether x must come before y. Returns the number of swaps.
template <typename T, typename Less>
int selectionSort(vector<T> &a, Less less) {
    int swaps = 0;
    int n = static_cast<int>(a.size());
    for (int i = 0; i < n - 1; i++) {
        int minIndex = i;                              // find the smallest element of a[i..n-1]
        for (int j = i + 1; j < n; j++)
            if (less(a[j], a[minIndex]))
                minIndex = j;
        if (minIndex != i) {                           // at most one swap per pass
            swap(a[i], a[minIndex]);
            swaps++;
        }
    }
    return swaps;
}

struct Item {
    int key;
    char tag;
};

int main() {
    int n;
    cout << "Enter the number of elements: ";
    if (!(cin >> n) || n < 0) {
        cout << "Invalid size\n";
        return 1;
    }
    vector<int> arr(n);
    cout << "Enter " << n << " integers: ";
    for (int &x : arr) {
        if (!(cin >> x)) {
            cout << "Invalid input\n";
            return 1;
        }
    }

    int swaps = selectionSort(arr, [](int x, int y) { return x < y; });
    cout << "Sorted:";
    for (int x : arr) cout << ' ' << x;
    cout << "\nSwaps: " << swaps << '\n';

    // Selection sort is NOT stable: equal keys can change their relative order.
    vector<Item> items = {{2, 'a'}, {2, 'b'}, {1, 'c'}};
    selectionSort(items, [](const Item &x, const Item &y) { return x.key < y.key; });
    cout << "Stability demo, input (2,a) (2,b) (1,c) ->";
    for (const Item &it : items) cout << " (" << it.key << ',' << it.tag << ')';
    cout << "   <- (2,a) and (2,b) swapped order\n";
    return 0;
}
