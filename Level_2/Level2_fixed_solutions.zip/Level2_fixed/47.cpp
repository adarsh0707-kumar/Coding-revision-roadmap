/*
47. Frequency Counter Using std::unordered_map

Count how many times each integer occurs, using the standard library.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 47.cpp -o program
*/

#include <algorithm>
#include <iostream>
#include <unordered_map>
#include <utility>
#include <vector>
using namespace std;

int main() {
    int n;
    cout << "Enter the number of elements: ";
    if (!(cin >> n) || n < 0) {
        cout << "Invalid size\n";
        return 1;
    }

    unordered_map<int, int> freq;
    cout << "Enter " << n << " integers: ";
    for (int i = 0; i < n; i++) {
        int x;
        if (!(cin >> x)) {
            cout << "Invalid input\n";
            return 1;
        }
        freq[x]++;                                    // missing key is created with 0, then incremented
    }

    // An unordered_map has NO defined iteration order, so copy to a vector and sort for stable output.
    vector<pair<int, int>> entries(freq.begin(), freq.end());
    sort(entries.begin(), entries.end());             // by value, then count

    cout << "Frequencies (sorted by value):\n";
    for (const auto &[value, count] : entries)
        cout << "  " << value << ": " << count << '\n';

    if (!entries.empty()) {
        auto best = entries.front();
        for (const auto &e : entries)
            if (e.second > best.second) best = e;     // first maximum wins ties (smallest value)
        cout << "Most frequent: " << best.first << " (" << best.second << " times)\n";
    }
    return 0;
}
