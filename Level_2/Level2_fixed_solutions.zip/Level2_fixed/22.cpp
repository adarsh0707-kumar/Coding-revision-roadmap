/*
22. Pass by Value vs. Pass by Reference

Demonstrate the difference between passing arguments by value and by reference.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 22.cpp -o program
*/

#include <iostream>
#include <string>
using namespace std;

void incrementByValue(int n) {
    n++;
    cout << "  inside by value:     n = " << n << ", &n = " << &n << '\n';
}

void incrementByReference(int &n) {
    n++;
    cout << "  inside by reference: n = " << n << ", &n = " << &n << '\n';
}

void swapByValue(int a, int b) {
    int temp = a;
    a = b;
    b = temp;
    cout << "  inside swapByValue:     a = " << a << ", b = " << b << " (swapped, but only the copies)\n";
}

void swapByReference(int &a, int &b) {
    int temp = a;
    a = b;
    b = temp;
    cout << "  inside swapByReference: a = " << a << ", b = " << b << '\n';
}

// A const reference avoids copying a big object and forbids modifying it.
size_t countChars(const string &s) { return s.size(); }

int main() {
    int x, y;
    cout << "Enter two integers: ";
    if (!(cin >> x >> y)) {
        cout << "Invalid input\n";
        return 1;
    }

    cout << "\n--- increment ---\n";
    cout << "main:  x = " << x << ", &x = " << &x << '\n';
    incrementByValue(x);
    cout << "main after by value:     x = " << x << "  (unchanged)\n";
    incrementByReference(x);
    cout << "main after by reference: x = " << x << "  (changed)\n";

    cout << "\n--- swap ---\n";
    cout << "main before: x = " << x << ", y = " << y << '\n';
    swapByValue(x, y);
    cout << "main after swapByValue:     x = " << x << ", y = " << y << "  (unchanged)\n";
    swapByReference(x, y);
    cout << "main after swapByReference: x = " << x << ", y = " << y << "  (swapped)\n";

    string big = "a very long string we do not want to copy";
    cout << "\nconst reference, no copy: " << countChars(big) << " characters\n";
    return 0;
}
