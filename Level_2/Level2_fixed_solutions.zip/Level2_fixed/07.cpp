/*
7. Linear Search

Find a target element and return its index, or indicate that it is absent.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 07.cpp -o program
*/

#include <iostream>
#include <iterator>
using namespace std;

// Returns the index of the FIRST occurrence of target, or -1 if absent.
int linearSearch(const int arr[], int n, int target) {
    for (int i = 0; i < n; i++)
        if (arr[i] == target)
            return i;                // stop at the first match
    return -1;
}

int main() {
    int arr[] = {0, 1, 2, 5, 4, 3, 9, 7, 6, 8};
    int n = static_cast<int>(size(arr));

    int targets[] = {9, 99, 0, 8};   // middle, absent, first, last
    for (int t : targets) {
        int idx = linearSearch(arr, n, t);
        if (idx != -1) cout << t << " found at index " << idx << '\n';
        else           cout << t << " not found\n";
    }

    int dup[] = {4, 2, 4};
    cout << "First 4 in {4,2,4}: index " << linearSearch(dup, 3, 4) << '\n';
    cout << "Search in empty array: " << linearSearch(arr, 0, 1) << '\n';
    return 0;
}
