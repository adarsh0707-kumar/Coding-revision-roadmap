/*
38. Binary Search Iteratively

Find a target in a sorted array using binary search (iteratively).

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 38.cpp -o program
*/

#include <iostream>
#include <vector>
using namespace std;

// Returns the index of a match, or -1. Precondition: arr is sorted in ascending order.
int binarySearch(const vector<int> &arr, int target) {
    int low = 0;
    int high = static_cast<int>(arr.size()) - 1;      // search the closed range [low, high]
    while (low <= high) {
        int mid = low + (high - low) / 2;             // never overflows
        if (arr[mid] == target) return mid;
        if (arr[mid] < target) low = mid + 1;         // the target can only be in the right half
        else                   high = mid - 1;        // ... or in the left half
    }
    return -1;                                        // the range became empty: not present
}

// Bonus: index of the FIRST occurrence (useful with duplicates), or -1.
int firstOccurrence(const vector<int> &arr, int target) {
    int low = 0, high = static_cast<int>(arr.size()) - 1, answer = -1;
    while (low <= high) {
        int mid = low + (high - low) / 2;
        if (arr[mid] == target) {
            answer = mid;                             // remember it, then look further left
            high = mid - 1;
        } else if (arr[mid] < target) {
            low = mid + 1;
        } else {
            high = mid - 1;
        }
    }
    return answer;
}

int main() {
    int n;
    cout << "Enter the number of elements: ";
    if (!(cin >> n) || n < 0) {
        cout << "Invalid size\n";
        return 1;
    }

    vector<int> arr(n);
    cout << "Enter " << n << " integers in ascending order: ";
    for (int &x : arr) {
        if (!(cin >> x)) {
            cout << "Invalid input\n";
            return 1;
        }
    }
    for (int i = 1; i < n; i++) {
        if (arr[i - 1] > arr[i]) {
            cout << "The array must be sorted in ascending order\n";
            return 1;
        }
    }

    int target;
    cout << "Enter the target: ";
    if (!(cin >> target)) {
        cout << "Invalid input\n";
        return 1;
    }

    int index = binarySearch(arr, target);
    if (index == -1) {
        cout << "Not found\n";
    } else {
        cout << "Found at index " << index << '\n';
        cout << "First occurrence: index " << firstOccurrence(arr, target) << '\n';
    }
    return 0;
}
