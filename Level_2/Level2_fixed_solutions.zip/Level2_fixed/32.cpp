/*
32. Fibonacci Using Recursion

Generate Fibonacci numbers with a recursive function.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 32.cpp -o program
*/

#include <iostream>
#include <vector>
using namespace std;

long long calls = 0;                       // counts function calls, to compare the two versions

unsigned long long fibSlow(int n) {        // plain recursion: O(2^n) time
    calls++;
    if (n <= 1) return static_cast<unsigned long long>(n);
    return fibSlow(n - 1) + fibSlow(n - 2);
}

unsigned long long fibMemo(int n, vector<unsigned long long> &memo) {   // memoized: O(n) time
    calls++;
    if (n <= 1) return static_cast<unsigned long long>(n);
    if (memo[n] != 0) return memo[n];      // 0 means "not computed yet" (safe: F(n) > 0 for n >= 2)
    memo[n] = fibMemo(n - 1, memo) + fibMemo(n - 2, memo);
    return memo[n];
}

int main() {
    const int MAX_N = 93;                  // F(93) is the largest value that fits in unsigned long long
    int n;
    cout << "Enter n (0 to " << MAX_N << "): ";
    if (!(cin >> n) || n < 0 || n > MAX_N) {
        cout << "Invalid input: n must be between 0 and " << MAX_N << '\n';
        return 1;
    }

    vector<unsigned long long> memo(n + 1, 0);
    cout << "Fibonacci numbers F(0)..F(" << n << "): ";
    for (int i = 0; i <= n; i++) {
        if (i > 0) cout << ' ';
        cout << fibMemo(i, memo);
    }
    cout << '\n';

    if (n <= 35) {                         // plain recursion is too slow beyond this
        calls = 0;
        fibSlow(n);
        long long slowCalls = calls;

        vector<unsigned long long> fresh(n + 1, 0);
        calls = 0;
        fibMemo(n, fresh);
        cout << "Calls to compute F(" << n << "): plain = " << slowCalls
             << ", memoized = " << calls << '\n';
    }
    return 0;
}
