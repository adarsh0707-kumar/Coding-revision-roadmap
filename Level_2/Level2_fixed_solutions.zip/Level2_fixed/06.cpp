/*
6. Count Even and Odd Elements

Count the even and odd values in an array.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 06.cpp -o program
*/

#include <iostream>
#include <iterator>
using namespace std;

void countEvenOdd(const int arr[], int n, int &evenCount, int &oddCount) {
    evenCount = 0;
    oddCount = 0;
    for (int i = 0; i < n; i++) {
        if (arr[i] % 2 == 0) evenCount++;   // 0 and negative evens included
        else                 oddCount++;    // -3 % 2 == -1, so != 0 -> odd
    }
}

int main() {
    int a[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 11};
    int b[] = {-4, -3, 0};
    int c[] = {2, 4, 6};

    int even, odd;
    countEvenOdd(a, static_cast<int>(size(a)), even, odd);
    cout << "Even: " << even << ", Odd: " << odd << '\n';
    countEvenOdd(b, static_cast<int>(size(b)), even, odd);
    cout << "Even: " << even << ", Odd: " << odd << '\n';
    countEvenOdd(c, static_cast<int>(size(c)), even, odd);
    cout << "Even: " << even << ", Odd: " << odd << '\n';
    countEvenOdd(a, 0, even, odd);
    cout << "Empty -> Even: " << even << ", Odd: " << odd << '\n';
    return 0;
}
