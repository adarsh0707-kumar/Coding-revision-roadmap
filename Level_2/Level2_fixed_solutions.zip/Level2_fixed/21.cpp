/*
21. Prime Numbers Using Functions

Write a primality function and use it to print primes in a range.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 21.cpp -o program
*/

#include <iostream>
using namespace std;

bool isPrime(int n) {
    if (n <= 1) return false;
    if (n <= 3) return true;
    if (n % 2 == 0 || n % 3 == 0) return false;
    for (int i = 5; i <= n / i; i += 6)
        if (n % i == 0 || n % (i + 2) == 0)
            return false;
    return true;
}

void printPrimes(int start, int end) {
    bool first = true;
    for (int n = start;; ++n) {                 // safe even when end == INT_MAX
        if (isPrime(n)) {
            if (!first) cout << ' ';
            cout << n;
            first = false;
        }
        if (n == end) break;
    }
    cout << '\n';
}

int main() {
    int start, end;
    cout << "Enter the start and end of the range: ";
    if (!(cin >> start >> end)) {
        cout << "Error: invalid input\n";
        return 1;
    }
    if (start > end) {
        cout << "Error: start cannot exceed end\n";
        return 1;
    }

    cout << "Primes between " << start << " and " << end << ": ";
    printPrimes(start, end);
    return 0;
}
