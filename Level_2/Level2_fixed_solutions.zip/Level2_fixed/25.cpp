/*
25. Pointer Basics

Declare an integer and a pointer to it. Print the value, address, and dereferenced value.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 25.cpp -o program
*/

#include <iostream>
using namespace std;

int main() {
    int val = 100;
    int *ptr = &val;                                  // ptr stores the address of val

    cout << "Value of val                : " << val << '\n';
    cout << "Address of val (&val)       : " << &val << '\n';
    cout << "Value stored in ptr (address): " << ptr << '\n';
    cout << "Dereferenced value (*ptr)   : " << *ptr << '\n';
    cout << "Address of ptr itself (&ptr): " << &ptr << '\n';
    cout << "Size of a pointer           : " << sizeof(ptr) << " bytes\n";

    *ptr = 250;                                       // changes val through the pointer
    cout << "\nAfter *ptr = 250, val     : " << val << '\n';

    int *noTarget = nullptr;                          // a pointer with no target yet
    cout << "A null pointer holds        : " << noTarget << '\n';
    if (noTarget == nullptr)
        cout << "so it must not be dereferenced\n";
    return 0;
}
