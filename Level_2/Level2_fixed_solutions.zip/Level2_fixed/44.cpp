/*
44. Quick Sort

Implement quicksort and explain how pivot selection affects performance.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 44.cpp -o program
*/

#include <algorithm>
#include <iostream>
#include <random>
#include <utility>
#include <vector>
using namespace std;

mt19937 rng(random_device{}());

// Random pivot + three-way partition. After partitioning:
//   a[low .. lt-1] < pivot,   a[lt .. gt] == pivot,   a[gt+1 .. high] > pivot
// Elements equal to the pivot are never touched again, so many duplicates are cheap.
void quickSort(vector<int> &a, int low, int high) {
    while (low < high) {
        int pivot = a[uniform_int_distribution<int>(low, high)(rng)];
        int lt = low, i = low, gt = high;
        while (i <= gt) {
            if (a[i] < pivot)      swap(a[lt++], a[i++]);
            else if (a[i] > pivot) swap(a[i], a[gt--]);
            else                   i++;
        }
        // Recurse into the SMALLER side, loop on the larger one: stack depth stays O(log n).
        if (lt - low < high - gt) {
            quickSort(a, low, lt - 1);
            low = gt + 1;
        } else {
            quickSort(a, gt + 1, high);
            high = lt - 1;
        }
    }
}

void quickSort(vector<int> &a) {
    if (!a.empty()) quickSort(a, 0, static_cast<int>(a.size()) - 1);
}

void printArray(const char *label, const vector<int> &a) {
    cout << label;
    for (size_t i = 0; i < a.size(); i++) {
        if (i > 0) cout << ' ';
        cout << a[i];
    }
    cout << '\n';
}

int main() {
    vector<int> arr = {10, 7, 8, 9, 1, 5, 7, 10, 1};
    printArray("Original: ", arr);
    quickSort(arr);
    printArray("Sorted:   ", arr);

    // Self-test against std::sort on random arrays full of duplicates and negatives.
    mt19937 gen(99);
    int failures = 0;
    for (int t = 0; t < 2000; t++) {
        vector<int> v(gen() % 60);
        for (int &x : v) x = static_cast<int>(gen() % 15) - 7;
        vector<int> expected = v;
        sort(expected.begin(), expected.end());
        quickSort(v);
        if (v != expected) failures++;
    }
    cout << "Self-test against std::sort (2000 random arrays): " << (failures == 0 ? "passed" : "FAILED") << '\n';

    vector<int> allEqual(200000, 5);                  // the input that breaks the classic Lomuto version
    quickSort(allEqual);
    cout << "200000 equal elements sorted in one linear pass: " << (is_sorted(allEqual.begin(), allEqual.end()) ? "ok" : "NO") << '\n';
    return 0;
}
