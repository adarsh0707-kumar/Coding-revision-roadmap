/*
12. Check a String Palindrome

Decide whether a string reads the same forwards and backwards.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 12.cpp -o program
*/

#include <cctype>
#include <iostream>
#include <string>
using namespace std;

// Strict: case-sensitive, every character (spaces included) counts.
bool isPalindrome(const string &s) {
    size_t n = s.size();
    for (size_t i = 0; i < n / 2; i++)
        if (s[i] != s[n - 1 - i]) return false;
    return true;                                  // "" and 1 character are palindromes
}

// Relaxed: ignore case, spaces and punctuation.
bool isPalindromeRelaxed(const string &s) {
    int left = 0, right = static_cast<int>(s.size()) - 1;
    while (left < right) {
        while (left < right && !isalnum(static_cast<unsigned char>(s[left])))  left++;
        while (left < right && !isalnum(static_cast<unsigned char>(s[right]))) right--;
        if (tolower(static_cast<unsigned char>(s[left])) !=
            tolower(static_cast<unsigned char>(s[right])))
            return false;
        left++;
        right--;
    }
    return true;
}

int main() {
    string s;
    cout << "Enter a string: ";
    if (!getline(cin, s)) {
        cout << "No input\n";
        return 0;
    }

    cout << "Strict:  " << (isPalindrome(s) ? "palindrome" : "not a palindrome") << '\n';
    cout << "Relaxed: " << (isPalindromeRelaxed(s) ? "palindrome" : "not a palindrome") << '\n';
    return 0;
}
