/*
26. Modify a Variable Through a Pointer

Write a function that changes a variable's value using a pointer parameter.

Reviewed and fixed version. Compile: g++ -std=c++17 -Wall -Wextra -Wpedantic 26.cpp -o program
*/

#include <iostream>
using namespace std;

// Returns false if the pointer is null (nothing was changed).
bool setValue(int *ptr, int newValue) {
    if (ptr == nullptr) return false;
    *ptr = newValue;
    return true;
}

int main() {
    int value = 100;
    cout << "Before: value = " << value << '\n';

    if (setValue(&value, 230043))
        cout << "After:  value = " << value << '\n';

    if (!setValue(nullptr, 5))
        cout << "Null pointer rejected, nothing modified\n";
    return 0;
}
